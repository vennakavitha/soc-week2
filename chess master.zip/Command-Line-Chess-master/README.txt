// Andrew Boles - ckj771
// README.txt

THIS IS THE README FILE FOR CHESS SCRAMBLE GAME
-Included in the file are the following:
	-Player.java
	-Piece.java
	-Move.java
	-FileSystem.java
	-ChessTop.java
	-README.txt (this document)
	-boles_andrew_ckj771_report
-To play the game, open a command line window on a system that can compile and run Java programs. (The game was tested on a Windows 8 system.) Then navigate to this folder and run the following commands. Then follow the instructions on the screen.
	-javac ChessTop.java
	-java ChessTop
-For further information, refer to the report document.