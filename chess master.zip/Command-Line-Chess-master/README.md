# Command-Line-Chess
Java-based chess game that can be played in the terminal.

Please see README.txt for instructions on how to play the game.
